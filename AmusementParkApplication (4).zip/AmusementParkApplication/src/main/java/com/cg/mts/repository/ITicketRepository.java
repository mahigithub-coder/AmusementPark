package com.cg.mts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.mts.entities.Ticket;
import com.cg.mts.exception.CustomerNotFoundException;
import com.cg.mts.exception.TicketNotFoundException;

public interface ITicketRepository extends JpaRepository<Ticket,Integer>{
	
	//@Query()
	//public Ticket calculateBill(int customerId);

}


