package com.cg.mts.service;

import java.time.LocalDateTime;
import java.util.List;

import com.cg.mts.entities.Activity;
import com.cg.mts.entities.Admin;
import com.cg.mts.entities.Ticket;
import com.cg.mts.exception.AdminNotFoundException;

public interface IAdminService {
	
	
	public Admin insertAdmin(Admin admin);
	public Admin updateAdmin(Admin admin);
	public Admin deleteAdmin(int adminId) throws AdminNotFoundException;
	public List<Activity> getAllActivities(int customerId);
	public List<Activity> getAllActivities();
	public List<Activity> getActivitiesCustomerwise();
	public List<Activity> getActivitiesDatewise();
	public List<Activity> getAllActivitiesForDays(int customerId,LocalDateTime fromDate,LocalDateTime toDate);
	
	
	

}
