package com.cg.mts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mts.entities.Customer;
import com.cg.mts.service.ICustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	ICustomerService service;

	@PostMapping("/customer")
	public Customer insertCustomer(@RequestBody Customer customer) {
	
		return service.insertCustomer(customer);
	}

	@PutMapping("/customer")
	public Customer updateCustomer(@RequestBody Customer customer) {
		Customer c = service.updateCustomer(customer);
		return customer;
	}

	@DeleteMapping("/customer")
	public Customer deleteCustomer(int customerId) {
		Customer c = service.deleteCustomer(customerId);
		return null;
		
	}

	
	public List<Customer> viewCustomers() {

		return service.viewCustomers();
	}


	public Customer viewCustomer(int customerId) {

		return service.viewCustomer(customerId);
	}


	public Customer validateCustomer(String username, String password) {

		return service.validateCustomer(username, password);
	}
}
