package com.cg.mts.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mts.entities.Admin;
import com.cg.mts.entities.Ticket;
import com.cg.mts.exception.AdminNotFoundException;
import com.cg.mts.service.IAdminService;


@RestController
public class AdminController {
	@Autowired
	IAdminService service;

	
	@PostMapping("admin")
	public Admin insertAdmin(@PathVariable Admin admin) {

		return service.insertAdmin(admin);
	}

	@PutMapping("/admin")
	public Admin updateAdmin(@RequestBody Admin admin) {
		Admin a = service.updateAdmin(admin);
		return admin;
	}

	@DeleteMapping("/admin/{id}")
	public Admin deleteAdmin(@PathVariable int adminId) {

		 try {
			Admin a = service.deleteAdmin(adminId);
		} catch (AdminNotFoundException e) {
			
			e.printStackTrace();
		}
		 return null;
	}

	@GetMapping("/admin/{id}")
	public List<Ticket> getAllActivities(int customerId) {

		 service.getAllActivities(customerId);
		 return getAllActivities(customerId);
		
	}

	@GetMapping
	public List<Ticket> getAllActivities() {

		 service.getAllActivities();
		 return getAllActivities();
	}

	@GetMapping
	public List<Ticket> getActivitiesCustomerwise() {

		 service.getActivitiesCustomerwise();
		 return getActivitiesCustomerwise();
	}

	@GetMapping
	public List<Ticket> getActivitiesDatewise() {

		service.getActivitiesDatewise();
		return getActivitiesDatewise();
	}

	@GetMapping
	public List<Ticket> getAllActivitiesForDays(int customerId, LocalDateTime fromDate, LocalDateTime toDate) {

		 service.getAllActivitiesForDays(customerId, fromDate, toDate);
		 return getAllActivitiesForDays(customerId, fromDate, toDate);
		 }
}
