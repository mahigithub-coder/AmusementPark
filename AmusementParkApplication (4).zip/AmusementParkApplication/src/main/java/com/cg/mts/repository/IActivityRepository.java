package com.cg.mts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.mts.entities.Activity;
import com.cg.mts.exception.ActivityNotFoundException;

@Repository
public interface IActivityRepository extends JpaRepository <Activity,Integer> {
	
	@Query(value = "select count(charges) FROM activity_table where charges = ?1", nativeQuery = true)
	public int countActivitiesOfCharges(float charges);

	
}
