package com.cg.mts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mts.entities.Activity;
import com.cg.mts.exception.ActivityNotFoundException;
import com.cg.mts.repository.IActivityRepository;

@Service
public class ActivityService implements IActivityService {

	@Autowired
	IActivityRepository repository;

	@Override
	public Activity insertActivity(Activity activity) {
		return  repository.save(activity);
	}

	@Override
	public Activity updateActivity(Activity activity) {
		Activity a = repository.getById(activity.getActivityId());
		if (a==null)
			throw new ActivityNotFoundException("activity not found");
		else
			a.setCharges(activity.getCharges());
			a.setDescription(activity.getDescription());
			a.setActivityId(activity.getActivityId());
		repository.save(a);
		return a;
	}

	@Override
	public Activity deleteActivity(int activityId) {
		 repository.deleteById(activityId);
		 return null;
		
	}

	@Override
	public List<Activity> viewActivitiesOfCharges(float charges) {
		return repository.findAll();
		
	}

	@Override
	public int countActivitiesOfCharges(float charges) {
		 
		 repository.count();
		 return countActivitiesOfCharges(charges);
	}

	
	

	

}
