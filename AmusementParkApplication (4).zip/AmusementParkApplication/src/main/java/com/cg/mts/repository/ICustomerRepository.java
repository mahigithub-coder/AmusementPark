package com.cg.mts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.mts.entities.Customer;
import com.cg.mts.exception.CustomerNotFoundException;

public interface ICustomerRepository extends JpaRepository<Customer,Integer>{
	@Query(value = "select * from customer c where c.username = ?1 AND c.password= ?2", nativeQuery = true)
	public Customer validateCustomer(String username,String password);
	
	

}
